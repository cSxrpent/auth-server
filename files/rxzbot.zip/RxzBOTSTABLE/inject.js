console.log('🔵 Inject.js loading...')

// Communication bridge pour l'auth
document.addEventListener('EXTENSION_AUTH_REQUEST', (event) => {
  console.log('🔵 Inject.js: Forwarding auth request to content script')
  // Le content-script.js (qui tourne en parallèle) va capter cet event
})

console.log('🔵 Inject.js ready')

// Ensuite votre code normal d'injection des autres scripts...

function injectScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    const url = chrome.runtime.getURL(src);
    
    // Debug: log the URL being injected
    console.log('Injecting script:', url);
    
    // Check if URL is valid
    if (!url || url.includes('invalid')) {
      reject(new Error(`Invalid URL for ${src}: ${url}`));
      return;
    }
    
    script.src = url;
    script.type = 'text/javascript';
    script.onload = function () {
      console.log(`✓ Loaded: ${src}`);
      resolve();
      this.remove();
    };
    script.onerror = function(err) {
      console.error(`✗ Failed to load: ${src}`, err);
      reject(new Error(`Failed to load ${src}`));
    };
    
    (document.head || document.documentElement).appendChild(script);
  });
}

(async () => {
  try {
    // Wait for document to be ready
    if (document.readyState === 'loading') {
      await new Promise(resolve => {
        document.addEventListener('DOMContentLoaded', resolve, { once: true });
      });
    }
    
    await injectScript('lib/abc.js');
    await injectScript('lib/defpayload.js');
    await injectScript('lib/payload.js');
    await injectScript('lib/notpayload.js');
    await injectScript('lib/replayer.js');

    console.log('✓ All scripts loaded successfully.');
    
  } catch (err) {
    console.error('Error fetching or injecting scripts:', err);
    alert(`Zoro Extension Error: Failed to load scripts.\n${err.message}\n\nPlease reload the page or reinstall the extension.`);
  }
})();