console.log('🔧 Background script loaded')

function click(x, y, button = 'left') {
  chrome.tabs.query({ url: "*://www.wolvesville.com/*" }, function (tabs) {
    if (tabs.length === 0) return console.warn("No Wolvesville tab found");
    const target = { tabId: tabs[0].id };

    chrome.debugger.attach(target, '1.2', function () {
      chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
      chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        button,
        x,
        y,
        clickCount: 1,
      })
      chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        button,
        x,
        y,
        clickCount: 1,
      })
    })
  })
}

// Fonction pour faire l'authentification
async function authenticateUser(username) {
  console.log('🔧 Auth request for username:', username)
  
  const AUTH_SERVER_URL = "https://auth-server-aj8k.onrender.com"
  const url = `${AUTH_SERVER_URL}/auth?username=${encodeURIComponent(username)}`
  
  console.log('🔧 Fetching:', url)
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    })
    
    console.log('🔧 Response status:', response.status)
    const data = await response.json()
    
    return {
      status: response.status,
      data: data
    }
  } catch (error) {
    console.error('🔧 Auth error:', error)
    return { 
      error: error.message,
      status: 0,
      data: { message: 'error' }
    }
  }
}

// Exposer la fonction d'authentification via messaging
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('🔧 Background received message:', request)
  
  if (request.x !== undefined && request.y !== undefined) {
    console.log('🔧 Click event')
    click(request.x, request.y)
    return false
  }
  
  if (request.type === 'AUTH_REQUEST') {
    authenticateUser(request.username).then(sendResponse)
    return true
  }
  
  return false
})

console.log('🔧 Background ready')