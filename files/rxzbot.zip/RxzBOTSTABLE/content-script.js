// Content script qui fait le pont
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Ce script reçoit les messages du background et les injecte dans la page
  return false
})

// Écouter les events personnalisés de la page
document.addEventListener('EXTENSION_AUTH_REQUEST', async (event) => {
  console.log('📨 Content script: Auth request received', event.detail.username)
  
  // Envoyer au background
  chrome.runtime.sendMessage(
    {
      type: 'AUTH_REQUEST',
      username: event.detail.username
    },
    (response) => {
      console.log('📨 Content script: Response received', response)
      
      // Renvoyer à la page
      document.dispatchEvent(new CustomEvent('EXTENSION_AUTH_RESPONSE', {
        detail: response
      }))
    }
  )
})

console.log('📨 Content script ready')