// Suppress console output in popup to reduce noise
try {
  (function(){
    const noop = function(){};
    if (typeof console !== 'undefined') {
      console.log = noop;
      console.info = noop;
      console.debug = noop;
      console.warn = noop;
      console.error = noop;
    }
  })();
} catch(e) {}

// State
let sessionXP = 0;
let userCoins = 0;
let userRoses = 0;
let username = '';
let userLevel = 0;
let licenseExpiry = '';
let settingsInitialized = false; 

settingsInitialized = false;
// Check if extension context is valid
function isContextValid() {
  try {
    return chrome.runtime && chrome.runtime.id;
  } catch (e) {
    return false;
  }
}

// Show error if context is invalid
if (!isContextValid()) {
  document.body.innerHTML = `
    <div style="padding: 20px; text-align: center; color: #ff4757;">
      <h2>⚠️ Extension Reloaded</h2>
      <p>Please reload the Wolvesville page to continue.</p>
      <button onclick="chrome.tabs.query({url:'*://www.wolvesville.com/*'}, tabs => tabs[0] && chrome.tabs.reload(tabs[0].id))" 
        style="padding: 10px 20px; background: #00d4ff; border: none; border-radius: 8px; color: #fff; cursor: pointer; font-weight: 600;">
        Reload Page
      </button>
    </div>
  `;
  throw new Error('Extension context invalidated');
}

// DOM Elements
const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const navItems = document.querySelectorAll('.nav-item');
const navCards = document.querySelectorAll('.nav-card');
const pages = document.querySelectorAll('.page');

// Connect to background for message relay
const port = chrome.runtime.connect({ name: 'popup' });

// Track recent wheel spin to show contextual footer notifications
let recentSpin = null; // { type: 'gold'|'rose', time: timestamp }

// Message state elements
const messagesBtn = document.getElementById('messagesBtn');
const messagesBadge = document.getElementById('messagesBadge');

// Send message to page via background
function sendToPage(message) {
  chrome.tabs.query({ url: "*://www.wolvesville.com/*" }, (tabs) => {
    if (tabs && tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'POPUP_TO_PAGE',
        data: message
      }).catch(err => {
        // ignore send errors
      });
    } else {
      // no wolvesville tab
    }
  });
}

// Listen for messages from background (relayed from page)
port.onMessage.addListener((message) => {
  handleMessage(message);
});

// Handle incoming messages
function handleMessage(data) {
  if (data.type === 'UPDATE_UI') {
    if (data.username) {
      username = data.username;
      document.getElementById('welcomeTitle').textContent = `Welcome ${username}`;
    }
    
    if (data.level) {
      userLevel = data.level;
      document.getElementById('userLevel').textContent = data.level;
    }
    
    if (data.licenseExpiry) {
      licenseExpiry = data.licenseExpiry;
      document.getElementById('licenseStatus').textContent = `Active until ${data.licenseExpiry}`;
    }

    // (No auth UI changes here) — auth status is handled via explicit AUTH_STATUS messages from the page
    
    if (data.coins !== undefined) {
      const prev = userCoins;
      userCoins = data.coins;
      const coinsEl = document.getElementById('userCoins');
      if (coinsEl) coinsEl.textContent = data.coins.toLocaleString();

      // If a recent spin occurred, show +coins notification
      if (recentSpin && Date.now() - recentSpin.time < 6000) {
        const delta = userCoins - prev;
        if (delta > 0) showFooterNotification(`+${delta} Coins`, 'coins');
        recentSpin = null;
      }
    }
    
    if (data.roses !== undefined) {
      userRoses = data.roses;
      const rosesEl = document.getElementById('userRoses');
      if (rosesEl) rosesEl.textContent = data.roses.toLocaleString();

      // If user has less than 30 roses, disable Rose Wheel visually
      const roseBtn = document.getElementById('roseWheelBtn');
      const roseStatus = roseBtn && roseBtn.querySelector('.wheel-status');
      if (roseBtn) {
        if (userRoses < 30) {
          roseBtn.dataset.available = 'false';
          roseBtn.disabled = true;
          if (roseStatus) roseStatus.textContent = `${userRoses} 🌹 — Need 30`;
        } else {
          roseBtn.dataset.available = 'true';
          roseBtn.disabled = false;
          if (roseStatus) roseStatus.textContent = `30 🌹 per spin`;
        }
      }
    }
    
    if (data.sessionXP !== undefined) {
      sessionXP = data.sessionXP;
      document.getElementById('sessionXP').textContent = data.sessionXP.toLocaleString();
    }
    
    if (data.lootBoxCount !== undefined) {
      document.getElementById('lootBoxCount').textContent = `(${data.lootBoxCount} available)`;
    }
    
    if (data.goldWheelAvailable !== undefined) {
      const goldBtn = document.getElementById('goldWheelBtn');
      if (goldBtn) {
        goldBtn.dataset.available = data.goldWheelAvailable ? 'true' : 'false';
        goldBtn.disabled = !data.goldWheelAvailable;
      }
      const goldStatus = document.getElementById('goldWheelStatus');
      if (goldStatus) goldStatus.textContent = data.goldWheelAvailable ? 'Available' : data.goldWheelStatus || 'Unavailable';
    }
    
    if (data.wheelResult) {
      const resultDiv = document.getElementById('wheelResult');
      if (resultDiv) {
        resultDiv.textContent = data.wheelResult;
        resultDiv.classList.add('visible');
        setTimeout(() => resultDiv.classList.remove('visible'), 5000);
      }
      showFooterNotification(data.wheelResult, 'result');
    }
  }

    // Show server-sent custom message inside popup UI and track seen state
    if (data.type === 'CUSTOM_MESSAGE' && data.message) {
      try {
        // persist last message and mark unseen until user acknowledges
        try { localStorage.setItem('last-custom-msg', data.message); } catch (e) {}
        try { localStorage.setItem('rxz_popup_msg_seen', 'false'); } catch (e) {}
        // also persist to chrome.storage so the popup state survives when reopened
        try {
          if (chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ 'last-custom-msg': data.message, 'rxz_popup_msg_seen': false }, function() {});
          }
        } catch (ee) {}
        updateMessageBadge();
        // Auto-show modal once when received
        showPopupCustomMessage(data.message);
      } catch (e) { console.error(e); }
    }

    // Handle explicit auth status messages from the page
    if (data.type === 'AUTH_STATUS') {
      try {
        const status = data.status;
        const licenseEl = document.getElementById('licenseStatus');
        if (status === 'authorized') {
          licenseExpiry = data.expires || '';
          if (licenseEl) licenseEl.textContent = licenseExpiry ? `Active until ${licenseExpiry}` : 'Active';
          try { restoreSettingsOnAuth(); } catch (e) {}
          try { hideDeactivatedOverlay(); } catch (e) {}
          if (data.custom_message) {
            try { localStorage.setItem('last-custom-msg', data.custom_message); } catch (e) {}
            try { localStorage.setItem('rxz_popup_msg_seen', 'false'); } catch (e) {}
            try { if (chrome && chrome.storage && chrome.storage.local) chrome.storage.local.set({ 'last-custom-msg': data.custom_message, 'rxz_popup_msg_seen': false }, function() {}); } catch (e) {}
            try { updateMessageBadge(); } catch (e) {}
            try { showPopupCustomMessage(data.custom_message); } catch (e) {}
          }
        } else {
          if (licenseEl) licenseEl.textContent = 'NOT AUTHORIZED — BOT DEACTIVATED';
          try { disableAllSettings(); } catch (e) {}
          try { showDeactivatedOverlay(); } catch (e) {}
          if (data.custom_message) {
            try { localStorage.setItem('last-custom-msg', data.custom_message); } catch (e) {}
            try { localStorage.setItem('rxz_popup_msg_seen', 'false'); } catch (e) {}
            try { if (chrome && chrome.storage && chrome.storage.local) chrome.storage.local.set({ 'last-custom-msg': data.custom_message, 'rxz_popup_msg_seen': false }, function() {}); } catch (e) {}
            try { updateMessageBadge(); } catch (e) {}
            try { showPopupCustomMessage(data.custom_message); } catch (e) {}
          }
        }
      } catch (err) { console.error('AUTH_STATUS handling error', err); }
    }
  
 if (data.type === 'SETTINGS_LOADED' || data.type === 'SETTINGS_UPDATED') {
    // ✅ Update UI with current settings (works for both initial load and updates)
    const settings = data.settings;
    
    const elAutoReplay = document.getElementById('autoReplayToggle');
    if (elAutoReplay) elAutoReplay.checked = settings.AUTO_REPLAY;

    const elAutoPlay = document.getElementById('autoPlayToggle');
    if (elAutoPlay) elAutoPlay.checked = settings.AUTO_PLAY;

    const elShowHidden = document.getElementById('showHiddenLvlToggle');
    if (elShowHidden) elShowHidden.checked = settings.SHOW_HIDDEN_LVL;

    // Keep chatStatsToggle code but guard it so missing element doesn't break everything
    const elChatStats = document.getElementById('chatStatsToggle');
    if (elChatStats) elChatStats.checked = settings.CHAT_STATS;

    const elDebug = document.getElementById('debugModeToggle');
    if (elDebug) elDebug.checked = settings.DEBUG_MODE;

    const elAura = document.getElementById('playerAuraToggle');
    if (elAura) {
      elAura.dataset.enabled = settings.PLAYER_AURA;
      const st = elAura.querySelector('.feature-status');
      if (st) st.textContent = settings.PLAYER_AURA ? 'Enabled' : 'Disabled';
    }

    const elNotes = document.getElementById('playerNotesToggle');
    if (elNotes) {
      elNotes.dataset.enabled = settings.PLAYER_NOTES;
      const st2 = elNotes.querySelector('.feature-status');
      if (st2) st2.textContent = settings.PLAYER_NOTES ? 'Enabled' : 'Disabled';
    }
    
    if (!settingsInitialized) {
      settingsInitialized = true;
    }
  }
}

// Navigation
function navigateToPage(pageName) {
  navItems.forEach(item => {
    item.classList.toggle('active', item.dataset.page === pageName);
  });
  
  pages.forEach(page => {
    page.classList.toggle('active', page.id === `page-${pageName}`);
  });
  
  closeSidebar();
}

function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.classList.add('visible');
}

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('visible');
}

// Event Listeners
menuBtn.addEventListener('click', openSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);

navItems.forEach(item => {
  item.addEventListener('click', () => {
    navigateToPage(item.dataset.page);
  });
});

navCards.forEach(card => {
  card.addEventListener('click', () => {
    navigateToPage(card.dataset.page);
  });
});

// Options toggles
const autoReplayToggle = document.getElementById('autoReplayToggle');
if (autoReplayToggle) {
  autoReplayToggle.addEventListener('change', function() {
    sendToPage({ type: 'SETTING_CHANGE', key: 'AUTO_REPLAY', value: this.checked });
  });
}

const autoPlayToggle = document.getElementById('autoPlayToggle');
if (autoPlayToggle) {
  autoPlayToggle.addEventListener('change', function() {
    sendToPage({ type: 'SETTING_CHANGE', key: 'AUTO_PLAY', value: this.checked });
  });
}

const showHiddenToggle = document.getElementById('showHiddenLvlToggle');
if (showHiddenToggle) {
  showHiddenToggle.addEventListener('change', function() {
    sendToPage({ type: 'SETTING_CHANGE', key: 'SHOW_HIDDEN_LVL', value: this.checked });
  });
}

// Keep chatStatsToggle listener but only attach if element exists
const chatStatsToggle = document.getElementById('chatStatsToggle');
if (chatStatsToggle) {
  chatStatsToggle.addEventListener('change', function() {
    sendToPage({ type: 'SETTING_CHANGE', key: 'CHAT_STATS', value: this.checked });
  });
}

const debugModeToggle = document.getElementById('debugModeToggle');
if (debugModeToggle) {
  debugModeToggle.addEventListener('change', function() {
    sendToPage({ type: 'SETTING_CHANGE', key: 'DEBUG_MODE', value: this.checked });
  });
}

// Wheel buttons
const goldWheelBtn = document.getElementById('goldWheelBtn');
if (goldWheelBtn) {
  goldWheelBtn.addEventListener('click', function() {
    if (this.dataset.available === 'true') {
      this.classList.add('spinning');
      recentSpin = { type: 'gold', time: Date.now() };
      showFooterNotification('Spinning Gold Wheel...', 'pending');
      sendToPage({ type: 'SPIN_GOLD_WHEEL' });
      setTimeout(() => {
        this.classList.remove('spinning');
        this.classList.add('success');
        setTimeout(() => this.classList.remove('success'), 2000);
      }, 500);
    } else {
      showFooterNotification('Gold Wheel unavailable', 'error');
    }
  });
}

const roseWheelBtn = document.getElementById('roseWheelBtn');
if (roseWheelBtn) {
  roseWheelBtn.addEventListener('click', function() {
    if (this.dataset.available === 'true') {
      this.classList.add('spinning');
      recentSpin = { type: 'rose', time: Date.now() };
      showFooterNotification('Spinning Rose Wheel...', 'pending');
      sendToPage({ type: 'SPIN_ROSE_WHEEL' });
      setTimeout(() => {
        this.classList.remove('spinning');
        this.classList.add('success');
        setTimeout(() => this.classList.remove('success'), 2000);
      }, 500);
    } else {
      showFooterNotification('Not enough roses', 'error');
    }
  });
}

// Feature toggles
document.getElementById('playerAuraToggle').addEventListener('click', function() {
  const enabled = this.dataset.enabled === 'true';
  this.dataset.enabled = !enabled;
  this.querySelector('.feature-status').textContent = !enabled ? 'Enabled' : 'Disabled';
  sendToPage({ type: 'TOGGLE_PLAYER_AURA', value: !enabled });
});

document.getElementById('playerNotesToggle').addEventListener('click', function() {
  const enabled = this.dataset.enabled === 'true';
  this.dataset.enabled = !enabled;
  this.querySelector('.feature-status').textContent = !enabled ? 'Enabled' : 'Disabled';
  sendToPage({ type: 'TOGGLE_PLAYER_NOTES', value: !enabled });
});

// Loot box button
const lootBoxBtn = document.getElementById('lootBoxBtn');
if (lootBoxBtn) {
  lootBoxBtn.addEventListener('click', function() {
    sendToPage({ type: 'OPEN_LOOT_BOXES' });
  });
}

// Request initial data when popup opens
sendToPage({ type: 'REQUEST_UI_DATA' });
sendToPage({ type: 'REQUEST_SETTINGS' }); // request settings

// Periodic data refresh (but NOT settings - they only change when user toggles)
setInterval(() => {
  sendToPage({ type: 'REQUEST_UI_DATA' });
}, 3000);

// Footer notification helper
function showFooterNotification(text, kind) {
  const wrap = document.getElementById('footerNotify');
  if (!wrap) return;
  wrap.textContent = text;
  wrap.className = 'footer-notify';
  if (kind) wrap.classList.add(`footer-${kind}`);
  wrap.classList.add('visible');
  if (kind !== 'pending') {
    setTimeout(() => wrap.classList.remove('visible'), 4000);
  } else {
    setTimeout(() => wrap.classList.remove('visible'), 6000);
  }
}

// Render a modal inside the popup UI for server custom messages
function showPopupCustomMessage(rawMessage) {
  if (!rawMessage) return;
  // Avoid duplicate if already present
  if (document.getElementById('rxz-popup-custom-msg')) return;

  const overlay = document.createElement('div');
  overlay.id = 'rxz-popup-custom-msg';
  overlay.className = 'rxz-modal-overlay';

  const panel = document.createElement('div');
  panel.className = 'rxz-modal-panel';

  const title = document.createElement('div');
  title.textContent = 'Message from RXZBot';
  title.className = 'rxz-modal-title';

  const content = document.createElement('div');
  content.className = 'rxz-modal-content';
  const parts = rawMessage.split('\n\n');
  parts.forEach(p => {
    const pEl = document.createElement('p');
    pEl.textContent = p.trim();
    pEl.style.margin = '8px 0';
    pEl.style.lineHeight = '1.5';
    pEl.style.fontSize = '14px';
    pEl.style.maxWidth = '90%';
    pEl.style.textAlign = 'center';
    content.appendChild(pEl);
  });

  const btn = document.createElement('button');
  btn.textContent = 'I Understand';
  btn.className = 'rxz-modal-btn';

  btn.addEventListener('click', () => {
    // mark message as seen and update badge
    try { localStorage.setItem('rxz_popup_msg_seen', 'true'); } catch (e) {}
    try { if (chrome && chrome.storage && chrome.storage.local) chrome.storage.local.set({ rxz_popup_msg_seen: true }, function() {}); } catch (e) {}
    try { updateMessageBadge(); } catch (e) {}
    overlay.remove();
  });

  // close button (top-right)
  const closeBtn = document.createElement('button');
  closeBtn.className = 'rxz-modal-close';
  closeBtn.innerHTML = '✕';
  closeBtn.title = 'Close';
  closeBtn.addEventListener('click', () => {
    try { localStorage.setItem('rxz_popup_msg_seen', 'true'); } catch (e) {}
    try { if (chrome && chrome.storage && chrome.storage.local) chrome.storage.local.set({ rxz_popup_msg_seen: true }, function() {}); } catch (e) {}
    try { updateMessageBadge(); } catch (e) {}
    overlay.remove();
  });

  panel.appendChild(title);
  panel.appendChild(content);
  panel.appendChild(btn);
  overlay.appendChild(panel);
  overlay.appendChild(closeBtn);
  document.body.appendChild(overlay);
  btn.focus();
}

// Update message badge visibility based on localStorage flags
function updateMessageBadge() {
  if (!messagesBadge) return;
  const lastMsg = localStorage.getItem('last-custom-msg');
  const seen = localStorage.getItem('rxz_popup_msg_seen');
  if (lastMsg && seen !== 'true') {
    messagesBadge.classList.remove('hidden');
    messagesBadge.textContent = '1';
  } else {
    messagesBadge.classList.add('hidden');
  }
}

// Messages button: open last message when clicked
if (messagesBtn) {
  messagesBtn.addEventListener('click', () => {
    const last = localStorage.getItem('last-custom-msg');
    if (last) {
      showPopupCustomMessage(last);
    }
  });
}

// Initialize badge on popup load — populate from chrome.storage.local so messages persist
if (chrome && chrome.storage && chrome.storage.local) {
  try {
    chrome.storage.local.get(['last-custom-msg', 'rxz_popup_msg_seen'], (res) => {
      try {
        if (res && res['last-custom-msg']) localStorage.setItem('last-custom-msg', res['last-custom-msg']);
        if (res && res['rxz_popup_msg_seen'] !== undefined) {
          localStorage.setItem('rxz_popup_msg_seen', res['rxz_popup_msg_seen'] ? 'true' : 'false');
        }
      } catch (e) {}
      try { updateMessageBadge(); } catch (e) {}
    });
  } catch (e) {
    try { updateMessageBadge(); } catch (err) {}
  }
} else {
  try { updateMessageBadge(); } catch (e) {}
}

// Show a non-dismissible overlay when the bot is not authorized
function showDeactivatedOverlay() {
  if (document.getElementById('rxz-deactivated-overlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'rxz-deactivated-overlay';
  overlay.style.position = 'fixed';
  overlay.style.inset = '0';
  overlay.style.background = 'linear-gradient(180deg, rgba(7,10,20,0.96), rgba(2,6,12,0.96))';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.zIndex = 10000;
  overlay.style.padding = '20px';

  const panel = document.createElement('div');
  panel.style.maxWidth = '420px';
  panel.style.width = '92%';
  panel.style.background = '#071026';
  panel.style.border = '1px solid rgba(255,255,255,0.04)';
  panel.style.borderRadius = '12px';
  panel.style.padding = '26px';
  panel.style.boxSizing = 'border-box';
  panel.style.textAlign = 'center';
  panel.style.color = '#fff';

  const title = document.createElement('div');
  title.textContent = 'NOT AUTHORIZED';
  title.style.fontSize = '20px';
  title.style.fontWeight = '800';
  title.style.color = '#ff8a8a';
  title.style.marginBottom = '10px';

  const subtitle = document.createElement('div');
  subtitle.textContent = 'BOT DEACTIVATED';
  subtitle.style.fontSize = '14px';
  subtitle.style.opacity = '0.95';
  subtitle.style.marginBottom = '6px';

  const info = document.createElement('div');
  info.textContent = 'Your license is inactive. The bot is disabled until a valid license is present.';
  info.style.fontSize = '13px';
  info.style.color = '#d7e9ff';
  info.style.opacity = '0.9';
  info.style.marginTop = '8px';

  panel.appendChild(title);
  panel.appendChild(subtitle);
  panel.appendChild(info);
  overlay.appendChild(panel);
  // Prevent keyboard interaction with underlying UI
  overlay.tabIndex = -1;
  document.body.appendChild(overlay);
}

function hideDeactivatedOverlay() {
  const el = document.getElementById('rxz-deactivated-overlay');
  if (el) el.remove();
}

// Save current settings and turn them all OFF, then notify page
function disableAllSettings() {
  // Avoid double-saving previous settings
  try {
    if (chrome && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['prev_settings'], (res) => {
        if (!res || !res.prev_settings) {
          const prev = {};
          const mapping = [
            { id: 'autoReplayToggle', key: 'AUTO_REPLAY' },
            { id: 'autoPlayToggle', key: 'AUTO_PLAY' },
            { id: 'showHiddenLvlToggle', key: 'SHOW_HIDDEN_LVL' },
            { id: 'chatStatsToggle', key: 'CHAT_STATS' },
            { id: 'debugModeToggle', key: 'DEBUG_MODE' },
            { id: 'playerAuraToggle', key: 'PLAYER_AURA', special: true },
            { id: 'playerNotesToggle', key: 'PLAYER_NOTES', special: true }
          ];

          mapping.forEach(m => {
            const el = document.getElementById(m.id);
            if (!el) return;
            let val = false;
            if (m.special) {
              val = (el.dataset.enabled === 'true');
            } else if (el.type === 'checkbox') {
              val = !!el.checked;
            } else {
              // fallback for button-like toggles
              val = (el.dataset.enabled === 'true');
            }
            prev[m.key] = val;
          });

          try { chrome.storage.local.set({ prev_settings: prev }, function() {}); } catch (e) {}
        }
      });
    }
  } catch (e) {}

  // Now turn off UI and send changes to page
  try {
    const turnOff = (id, key, special) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (special) {
        el.dataset.enabled = 'false';
        const st = el.querySelector('.feature-status'); if (st) st.textContent = 'Disabled';
        el.setAttribute('disabled', 'true');
      } else if (el.type === 'checkbox') {
        el.checked = false;
        el.setAttribute('disabled', 'true');
      } else {
        el.dataset.enabled = 'false';
        el.setAttribute('disabled', 'true');
      }
      try { sendToPage({ type: 'SETTING_CHANGE', key: key, value: false }); } catch (e) {}
    };

    turnOff('autoReplayToggle', 'AUTO_REPLAY');
    turnOff('autoPlayToggle', 'AUTO_PLAY');
    turnOff('showHiddenLvlToggle', 'SHOW_HIDDEN_LVL');
    turnOff('chatStatsToggle', 'CHAT_STATS');
    turnOff('debugModeToggle', 'DEBUG_MODE');
    turnOff('playerAuraToggle', 'PLAYER_AURA', true);
    turnOff('playerNotesToggle', 'PLAYER_NOTES', true);
  } catch (e) {}
}

// Restore previously-saved settings after license re-activation
function restoreSettingsOnAuth() {
  try {
    if (chrome && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['prev_settings'], (res) => {
        const prev = res && res.prev_settings;
        if (!prev) return;

        const apply = (id, key, special) => {
          const el = document.getElementById(id);
          if (!el) return;
          const val = !!prev[key];
          if (special) {
            el.dataset.enabled = val ? 'true' : 'false';
            const st = el.querySelector('.feature-status'); if (st) st.textContent = val ? 'Enabled' : 'Disabled';
            el.removeAttribute('disabled');
          } else if (el.type === 'checkbox') {
            el.checked = val;
            el.removeAttribute('disabled');
          } else {
            el.dataset.enabled = val ? 'true' : 'false';
            el.removeAttribute('disabled');
          }
          try { sendToPage({ type: 'SETTING_CHANGE', key: key, value: val }); } catch (e) {}
        };

        apply('autoReplayToggle', 'AUTO_REPLAY');
        apply('autoPlayToggle', 'AUTO_PLAY');
        apply('showHiddenLvlToggle', 'SHOW_HIDDEN_LVL');
        apply('chatStatsToggle', 'CHAT_STATS');
        apply('debugModeToggle', 'DEBUG_MODE');
        apply('playerAuraToggle', 'PLAYER_AURA', true);
        apply('playerNotesToggle', 'PLAYER_NOTES', true);

        // remove saved prev_settings
        try { chrome.storage.local.remove('prev_settings', function() {}); } catch (e) {}
      });
    }
  } catch (e) {}
}